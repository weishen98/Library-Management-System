<?php
error_reporting(0);
$set=mysqli_connect("localhost","root","","library2"); /*$conn = mysqli_connect("localhost", "hws_dbms", "123456", "library2");*/

?>